use kira::sound::static_sound::{PlaybackState, StaticSoundHandle};
use sdl2::{
    event::Event, 
    keyboard::{Keycode, Scancode, KeyboardState}, 
    rect::{Rect, Point}, 
    render::{Canvas, TextureCreator}, 
    image::{self, LoadTexture, InitFlag, LoadSurface},
    render::{WindowCanvas, Texture},
    pixels::Color,
    surface::{Surface, SurfaceRef}, 
    mouse::{MouseButton, MouseState},
};
use std::{time::{Instant, Duration}, thread::{sleep, panicking}, vec, f64::RADIX, os::windows};
use sdl2::video::WindowContext;
use sdl2::ttf;

use rand::prelude::*;

use kira::{
    manager::{
        AudioManager, AudioManagerSettings,
        backend::cpal::CpalBackend,
    },
    sound::static_sound::{StaticSoundData, StaticSoundSettings},
    track::TrackBuilder,
    tween::Tween,
};
use num_traits::AsPrimitive;

const SCREEN_WIDTH: u32 = 1920;
const SCREEN_HEIGHT: u32 = 1080;
const DEFAULT_ANIMATION_LENGTH: u64 = 100;
fn main() -> Result<(), String> {
    //creating context
    let sdl_context = sdl2::init()?;
    sdl_context.mouse().show_cursor(false);
    let video_subsystem = sdl_context.video()?;

    let displaymode = video_subsystem.current_display_mode(0);
    println!("{:?}", displaymode);

    let _image_context = image::init(InitFlag::PNG | InitFlag::JPG)?;

    let mut window = video_subsystem.window("Dr. Cat Games", SCREEN_WIDTH, SCREEN_HEIGHT)
        .position_centered()
        .build()
        .expect("could not init window (video subsys)");

    // Load the icon image into a surface
    let surface = Surface::load_bmp("assets/logo.bmp")?;
    // Set the icon of the window
    window.set_icon(surface);

    let mut canvas = window.into_canvas().build()
        .expect("could not make canvas");

    let window = Rect::new(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    //creating loader
    let loader: TextureCreator<_> = canvas.texture_creator();
    

    //defining character

    let mut standing = Animation::new("assets/front.png", 1, 2, vec![(0, 0), (1, 0)], &loader);
    standing.dur = Duration::from_millis(400);

    let right = Animation::new("assets/movements/right.png", 1, 4, vec![(0, 0), (1, 0), (2, 0), (3, 0)], &loader);
    let left = Animation::new("assets/movements/left.png", 1, 4, vec![(0, 0), (1, 0), (2, 0), (3, 0)], &loader);
    let down = Animation::new("assets/movements/front.png", 1, 5, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0)], &loader);
    let up = Animation::new("assets/movements/back.png", 1, 6, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0)], &loader);

    let frames = vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (8, 0), (9, 0), (10, 0), (11, 0), (12, 0), (13, 0), (14, 0)];
    let mut death = Animation::new("assets/death.png", 1, 15, frames, &loader);
    death.dur = Duration::from_millis(100);
    death.interruptable = false;
    death.looped = false;
    death.movable = false;

    //dash character animation
    let mut dash_left = Animation::new("assets/movements/dash_left.png", 1, 8, vec![(7, 0), (6, 0), (5, 0), (4, 0), (3, 0), (2, 0), (1, 0), (0, 0)], &loader);
    dash_left.dur = Duration::from_millis(20);
    dash_left.interruptable = false;
    dash_left.looped = false;
    let mut dash_right = Animation::new("assets/movements/dash_right.png", 1, 8, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0)], &loader);
    dash_right.dur = Duration::from_millis(20);
    dash_right.interruptable = false;
    dash_right.looped = false;
    let mut dash_front = Animation::new("assets/movements/dash_front.png", 1, 11, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (8, 0), (9, 0), (10, 0)], &loader);
    dash_front.dur = Duration::from_millis(20);
    dash_front.interruptable = false;
    dash_front.looped = false;
    let mut dash_back = Animation::new("assets/movements/dash_back.png", 1, 8, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0)], &loader);
    dash_back.dur = Duration::from_millis(20);
    dash_back.interruptable = false;
    dash_back.looped = false;
    //let dash_back = dash_front.clone(&loader);
    
    //attack
    let attack_right = Animation::from(
        "assets/attack.png", 1, 8, 
        vec![(0,0), (1,0), (2,0), (3, 0), (4,0), (5, 0), (6,0), (7,0)],
        false, false, false, false, Duration::from_millis(DEFAULT_ANIMATION_LENGTH),
        &loader);
    let attack_left = Animation::from(
        "assets/attack_left.png", 1, 8, 
        vec![(0,0), (1,0), (2,0), (3, 0), (4,0), (5, 0), (6,0), (7,0)],
        false, false, false, false, Duration::from_millis(DEFAULT_ANIMATION_LENGTH), 
        &loader);


    let mut sponge = Entity::new(
        vec![standing, left, right, up, down, death, dash_left, dash_right, dash_back, dash_front, attack_right, attack_left], 
        0, 0, 0, window.center()
    );

    sponge.mult_until_h(Percent::f32(window.height(), 15.0));
    sponge.hitbox = Rect::new(sponge.dst.w as i32 / 2 - 15, sponge.dst.h as i32 - 10, 25, 1);
    sponge.gen_hitbox();

    //game UI elements

    //defining hearts
    let heart_loss = Animation::from(
        "assets/selet.png", 1, 5, 
        vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0)], 
        false, false, true, true, Duration::from_millis(400),
        &loader);

    let mut heart = Entity::from(heart_loss.clone(&loader), Percent::i32(window.width(), 3.0), Percent::i32(window.width(), 3.0));
    heart.reference = window.top_left();
    heart.mult_until_w(Percent::f32(window.width(), 5.0));
    heart.mult_w(1.2);

    let mut heart2 = heart.clone(&loader);
    heart2.coords.x += Percent::i32(window.width(), 6.0);
    heart2.dst();

    let mut heart3 = heart2.clone(&loader);
    heart3.coords.x += Percent::i32(window.width(), 6.0);
    heart3.dst();

    //dash cooldown
    let dash_anim = Animation::from(
        "assets/dash.png", 7, 1, 
        vec![(0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6)],
        false, false, false, false, Duration::from_millis(286), 
        &loader);

    let mut dash = Entity::from(dash_anim, -Percent::i32(window.width(), 4.2), Percent::i32(window.width(), 2.8));
    dash.reference = window.top_right();
    dash.mult_until_w(Percent::f32(window.width(), 7.5));

    //key of igazsag
    let key = Animation::from(
        "assets/UI/keyofigazsag.png", 1, 3, vec![(2,0), (1,0), (0,0)],
        false, false, false, false, Duration::from_millis(DEFAULT_ANIMATION_LENGTH), 
        &loader
    );
    let mut key = Entity::from(key, -Percent::i32(window.width(), 4.2), -Percent::i32(window.width(), 4.2));
    key.reference = window.bottom_right();
    key.mult_until_w(Percent::f32(window.width(), 7.5));


    let sponge = Character::new(sponge, vec![heart, heart2, heart3]);

    //map test
    let map = Animation::new("assets/finished_map.png", 1, 1, vec![(0, 0)], &loader);
    let mut map = Entity::new(vec![map], 0, 0, 1, sponge.rep.reference);
    //resizing map here
    let x = map.mult_until_h(Percent::f32(window.height(), 900.0));
    map.coords.x = map.dst.w / 2; //centering map
    map.coords.y = map.dst.h / 2;
    map.coords -= Point::new((1055/7)*x as i32, (3459/7)*x as i32); //setting up spawn point for character
    map.dst();
    //map.z_index = 0;
    map.hitbox = Rect::new(0, 0, 0, 0);
    let mut map = ComplexHitbox::new(map);
    map.add_hitbox(Rect::new((416/7)*x as i32, (2922/7)*x as i32, (1284/7)*x as u32, (1213/7)*x as u32));
    map.add_hitbox(Rect::new((1130/7)*x as i32, (3350/7)*x as i32, (77/7)*x as u32, (33/7)*x as u32));
    
    let platform = Animation::from(
        "assets/map objects/platform.png", 1, 7, vec![(6, 0),(1, 0),(2, 0),(3, 0),(4, 0),(5, 0),(6, 0),],
        false, false, false, false, Duration::from_millis(200),
        &loader
    );
    let mut platform = Entity::new(vec![platform], size_up(709+(22/2)-1, x), size_up(633+(22/2), x), 0, map.base.dst.top_left());
    platform.hitbox = Rect::new(22, 38, 16, 5);
    platform.mult(x);



    //tree
    let tree = Animation::new("assets/tree.png", 1, 1, vec![(0, 0)], &loader);
    let mut tree = Entity::from(tree, (500/7)*x as i32, (2800/7)*x as i32);
    tree.mult(3.0);
    tree.z_index = 3;
    let mut tree_2 = tree.clone(&loader);
    tree.hitbox = Rect::new(tree.dst.w as i32 / 2 - 15, tree.dst.h as i32 -10, 25, 10);
    //tree.offset_x(100);
    
    
    tree_2.coords.x += 1088;
    tree_2.dst();
    tree_2.hitbox = Rect::new(tree_2.dst.w as i32 / 2 - 15, tree_2.dst.h as i32 -10, 25, 10);


    let mut cat = Animation::new("assets/TX Player.png", 1, 1, vec![(0, 0)], &loader);
    cat.current_frame.2 = Some(Rect::new(5, 13, 23, 45));
    let mut cat = Entity::new(vec![cat], (5195/7)*x as i32, (3835/7)*x as i32, 2, map.base.dst.top_left());
    cat.mult_until_h(Percent::f32(window.height(), 15.0));

    let mut stone = Entity::from(Animation::new("assets/map objects/stone 1.png", 1, 1, vec![(0, 0)], &loader), 1160, 3330);
    stone.mult(1.1);
    stone.hitbox = Rect::new(0, 89, 83, 24);

    cat.hitbox = Rect::new(0, cat.dst.h as i32 - 30, cat.dst.w as u32, 30);
    let mut cat = Animal::from(3, cat, Hitbox::new(Rect::new((4901/7)*x as i32, (3565/7)*x as i32, (563/7)*x as u32, (583/7)*x as u32), map.base.dst.top_left()));
    cat.add_hittingbox(Hitbox::new(Rect::new(-20, -20, 20*2, 20*2), cat.entity.dst.center()));

    let mut enemy = Entity::new(
        vec![
            Animation::new("assets/enemy/down.png", 1, 8, vec![(0, 0)], &loader),
            Animation::new("assets/enemy/down.png", 1, 8, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7,0)], &loader),
            Animation::new("assets/enemy/up.png", 1, 8, vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7,0)], &loader),
            Animation::new("assets/enemy/right.png", 3, 2, vec![(0, 0), (1, 0), (0, 1), (1, 1), (0, 2), (1, 2)], &loader),
            Animation::new("assets/enemy/left.png", 3, 2, vec![(0, 0), (1, 0), (0, 1), (1, 1), (0, 2), (1, 2)], &loader),
        ],
        size_up(150, x), size_up(530, x),
        2, map.base.dst.top_left()
    );    
    let mult = enemy.mult_until_h(Percent::f32(window.height(), 30.0));
    enemy.hitbox = Rect::new(size_up(22, mult), size_up(107, mult), size_up(78, mult) as u32, size_up(10, mult) as u32);
    let mut enemy = Enemy::from(3, enemy, Hitbox::new(Rect::new(-20, -20, 20*2, 20*2), Point::new(0, 0)));
    enemy.entity.switch_to(2);

    let mut world = World::from(map, vec![tree, stone, platform], 3, sponge, &loader);
    world.x = 5670;
    world.y = 370;
    world.add(cat);
    world.add(enemy);
    world.add(tree_2);

    //Interactables

    let mut test = Interactable::new(
        Rect::new((1128/7)*x as i32, (3383/7)*x as i32, (86/7)*x as u32, (36/7)*x as u32),
        Some({
            fn test() -> bool {
                println!("working?");
                true
            } test
        }),
        world.map.base.dst,
    );
    world.add_interaction(test);

    //text

    let ttf = sdl2::ttf::init().map_err(|e| e.to_string())?;

    let mut kezdes = Text::from(
        "JÁTÉK KEZDÉSE", 
        "assets/fonts/Aiden-v7DO.otf", 
        100, 
        Color::RGB(255, 255, 255),
        Point::new(10, 10),
        &ttf, &loader);
    kezdes.center();
    kezdes.dst.y -= 100;

    let mut kezdes = Button::new(
        Rect::new(0, 0, 400, 100), 
        Some({
            fn simple_callback() -> bool {
                    false
        } simple_callback
        }), 
        kezdes.current);
    kezdes.center();


    let mut retry = Text::from(
        "ÚJRAPRÓBA", 
        "assets/fonts/Aiden-v7DO.otf", 
        100, 
        Color::RGB(255, 0, 0),
        Point::new(10, 10),
        &ttf, &loader);
    retry.center();
    retry.dst.y -= 100;

    let mut retry = Button::new(
        Rect::new(0, 0, 400, 100), 
        Some({
            fn simple_callback2() -> bool {
                    true
        } simple_callback2
        }), 
        retry.current);
    retry.center();

    //logo
    let logo = Animation::new("assets/UI/DRcatgameslogo.png", 1, 1, vec![(0, 0)], &loader);
    let mut logo = Entity::from(logo, 0, 0);
    logo.mult_until_h(Percent::f32(window.height(), 75.0));
    logo.center();



    //sound
    
    // Create an audio manager. This plays sounds and manages resources.
 
    let mut manager = AudioManager::<CpalBackend>::new(AudioManagerSettings::default()).unwrap();
    let track = manager.add_sub_track(TrackBuilder::default()).unwrap();
    let track2 = manager.add_sub_track(TrackBuilder::default()).unwrap();
    let track3 = manager.add_sub_track(TrackBuilder::default()).unwrap();
    
    let sound_data = StaticSoundData::from_file("assets/sounds/running_in_grass.mp3", StaticSoundSettings::new().track(&track)).unwrap();
    let mut sound = manager.play(sound_data.clone()).unwrap();
    sound.set_volume(1f64, Tween { ..Default::default() });
    let mut running = Audio {data: sound_data, current: sound};
    
    let sound_data = StaticSoundData::from_file("assets/sounds/slash.mp3", StaticSoundSettings::new().track(&track2)).unwrap();
    let sound = manager.play(sound_data.clone()).unwrap();
    let mut slash = Audio {data: sound_data, current: sound};
    
    //let sound_data = StaticSoundData::from_file("assets/sounds/background.mp3", StaticSoundSettings::default()).unwrap();
    //let mut sound = manager.play(sound_data.clone()).unwrap();
   // sound.set_volume(0.2f64, Tween { ..Default::default() });
    //let mut background = Audio {data: sound_data, current: sound};

  //  background.play(&mut manager);

    // After a couple seconds...
    // Cloning the sound data will not use any extra memory.
    let mut youdied = Entity::new(
        vec![
            Animation::from("assets/UI/youdied.png", 1, 11, 
        vec![(0, 0), (1, 0), (2, 0), (3, 0), (4, 0), (5, 0), (6, 0), (7, 0), (8, 0), (9, 0), (10, 0)],
        false, false, false, false, Duration::from_millis(200), 
        &loader)],
        0, 0, 0,
        window.center(),
    );
    youdied.mult(3.0);
    youdied.center();


    let y = x;

    //game loop
    let mut event_pump = sdl_context.event_pump()?;
    let mut i: u8 = 0;
    let mut menu = true;
    'running: for i in 0..255 {
        //event handling
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit {..} |
                Event::KeyDown {keycode: Some(Keycode::Escape), .. } => {
                    break 'running
                },
                _ => {}
            }
        }
        canvas.set_draw_color(Color::RGB(255-i, 255-i, 255-i));
        canvas.clear();

        logo.present(&mut canvas)?;

        canvas.present();
        //ticks
        sleep(Duration::new(0, 1_000_000_000u32 / 60));
    }

    'running: loop {
        
        canvas.clear();

        //get mouse
        let mouse = event_pump.mouse_state();
        //get keyboard
        let keyboard = event_pump.keyboard_state();


        if menu {
            if let Some(res) = kezdes.exec(&mouse) {
                let res = res();
                println!("{:?}", res);
                menu = res;
            }
            kezdes.present(&mut canvas)?;
        }

        
        else if !menu {

            if keyboard.is_scancode_pressed(Scancode::K) {
                world.char.hearts[0].play(None);
                world.char.hearts[1].play(None);
                world.char.hearts[2].play(None);
                world.char.rep.play(Some(5));
            }
            if keyboard.is_scancode_pressed(Scancode::Right) {
                slash.play(&mut manager);
                world.char.rep.play(Some(10));
            }
            else if keyboard.is_scancode_pressed(Scancode::Left) {
                slash.play(&mut manager);
                world.char.rep.play(Some(11));
            }

            let mut moved = false;
            if world.char.rep.movable() {
                //checking for sprint
                world.char.speed(&keyboard, &mut dash);

                //movement
                moved = world.movement(&keyboard);
            }
            //if not moved then stand
            if !moved {
                world.char.rep.switch_to(0);
                running.stop(0);
            } else {
                world.map.base.dst();
                running.play(&mut manager);
            }

            world.reorder_char();

            //play next frame of animations
            dash.next();

            world.do_behaviours();

            world.check_hits();

            //new_frame
            i = (i + 1) % 255;
            //rendering

            canvas.set_draw_color(Color::RGB(i, 64, 255 - i));
        

            world.present(&mut canvas)?;

            if let Some((x, i)) = world.check_interact(&keyboard, &mut canvas) {
                println!("{:?} {}", x, i);
                match i {
                    0 => {
                        world.map.add_hitbox(Rect::new((1600 as f32 *y/7.0) as i32, (3474 as f32 *y/7.0) as i32, ((1452+86) as f32 *y/7.0) as u32, (59 as f32 *y/7.0) as u32));
                        world.map.add_hitbox(Rect::new((3061 as f32 *y/7.0) as i32, (3474 as f32 *y/7.0) as i32, (78 as f32 *y/7.0) as u32, (923 as f32 *y/7.0) as u32));
                        world.map.add_hitbox(Rect::new((3061 as f32 *y/7.0) as i32, (4294 as f32 *y/7.0) as i32, (1320 as f32 *y/7.0) as u32, (59 as f32 *y/7.0) as u32));
                        world.map.add_hitbox(Rect::new((4263 as f32 *y/7.0) as i32, (3513 as f32 *y/7.0) as i32, (698 as f32 *y/7.0) as u32, (111 as f32 *y/7.0) as u32));
                        world.map.add_hitbox(Rect::new((4263 as f32 *y/7.0) as i32, (3513 as f32 *y/7.0) as i32, (1227 as f32 *y/7.0) as u32, (645 as f32 *y/7.0) as u32));
                        world.map.add_hitbox(Rect::new((608 as f32 *y) as i32, (501 as f32 *y) as i32, (101 as f32 *y) as u32, (158 as f32 *y) as u32));

                    }
                    _ => {todo!()}
                }
            }
            dash.present(&mut canvas)?;
            key.present(&mut canvas)?;
            //platform.set_reference(world.map.base.dst.top_left());
            //platform.present(&mut canvas)?;

            if world.char.health == 0 {
                youdied.play(None);
                'end: loop {
                    world.present(&mut canvas)?;

                    println!("dead");

                    if youdied.current_as_ref().has_ended() {
                        'returning: for i in 0..255 {
                            //event handling
                            for event in event_pump.poll_iter() {
                                match event {
                                    Event::Quit {..} |
                                    Event::KeyDown {keycode: Some(Keycode::Escape), .. } => {
                                        break 'running
                                    },
                                    _ => {}
                                }
                            }
                            canvas.set_draw_color(Color::RGB(i, i, i));
                            canvas.clear();
                            youdied.present(&mut canvas)?;

                            canvas.present();
                            sleep(Duration::new(0, 1_000_000_000u32 / 60));
                        }
                        'retry: loop {
                            //get mouse
                            let mouse = event_pump.mouse_state();
                            canvas.clear();
                            if let Some(res) = retry.exec(&mouse) {
                                let res = res();
                                println!("{:?}", res);
                                if res {
                                    break 'running
                                }
                            }
                            retry.present(&mut canvas)?;
//
                            for event in event_pump.poll_iter() {
                                match event {
                                    Event::Quit {..} |
                                    Event::KeyDown {keycode: Some(Keycode::Escape), .. } => {
                                        break 'running
                                    },
                                    _ => {}
                                }
                            }
                            canvas.present();
                            sleep(Duration::new(0, 1_000_000_000u32 / 60));
                        }    
                    } else {
                        youdied.next();
                    }
                    youdied.present(&mut canvas)?;

                    //event handling
                    for event in event_pump.poll_iter() {
                        match event {
                            Event::Quit {..} |
                            Event::KeyDown {keycode: Some(Keycode::Escape), .. } => {
                                break 'end
                            },
                            _ => {}
                        }
                    }
                    canvas.present();
                    sleep(Duration::new(0, 1_000_000_000u32 / 60));
                }
            }

        }

        //event handling
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit {..} |
                Event::KeyDown {keycode: Some(Keycode::Escape), .. } => {
                    break 'running
                },
                _ => {}
            }
        }
        canvas.present();
        sleep(Duration::new(0, 1_000_000_000u32 / 60));
    }

    Ok(())
}
struct ComplexHitbox<'a> {
    base: Entity<'a>,
    ideal: Vec<Rect>,
    real: Vec<Rect>
}
impl<'a> ComplexHitbox<'a> {
    fn create_real(&self, hitbox: Rect) -> Rect {
        Rect::new(
            self.base.dst.x() + hitbox.x(),
            self.base.dst.y() + hitbox.y(),
            hitbox.width(),
            hitbox.height()
        )
    }
    fn add_hitbox(&mut self, ideal: Rect) {
        let real = self.create_real(ideal);
        self.real.push(real);
        self.ideal.push(ideal);
    }
    fn add_hitboxes(&mut self, ideals: Vec<Rect>) {
        for ideal in ideals {
            self.add_hitbox(ideal)
        }
    }
    fn collide_all(&self, other: Rect) -> bool {
        for ideal in &self.ideal {
            let mut copy = *ideal;
            copy.x += self.base.dst.x;// + (self.base.dst.w / (7 * 2));
            copy.y += self.base.dst.y;// + (self.base.dst.h / (7 * 2));
            if copy.contains_rect(other) {
                //println!("{}", copy.has_intersection(other));
                return false
            }
        }
        true
    }
    fn new(base: Entity<'a>) -> Self {
        let base_hitbox = base.hitbox;
        let new = ComplexHitbox { base, ideal: vec![base_hitbox], real: vec![base_hitbox] };
        new
    }
}
struct Interactable {
    hitbox: Rect,
    callback: Option<fn() -> bool>,
    reference: Point,
}
impl Interactable{
    fn new(hitbox: Rect, callback: Option<fn() -> bool>, map_dst: Rect) -> Self {
        Interactable {
            hitbox, callback, reference: map_dst.top_left(),
        }
    }
    fn hitbox(&self) -> Rect {
        Rect::new(
            self.hitbox.x() + self.reference.x(),
            self.hitbox.y() + self.reference.y(),
            self.hitbox.width(), self.hitbox.height(),
        )
    }
    fn update_ref(&mut self, new_ref: Point) {
        self.reference = new_ref;
    }
    fn check(&self, hitbox: Rect) -> bool {
        let interactable_hitbox = self.hitbox();
        if hitbox.has_intersection(interactable_hitbox) {
            println!("yoooo");
            return true
        }
        false
    }
    fn exec(&self, keyboard: &KeyboardState) -> Option<fn() -> bool> {
        if keyboard.is_scancode_pressed(Scancode::E) {
            return self.callback
        }
        None
    }
    
}
struct Button<'a, T> {
    hitbox: Rect,
    callback: Option<fn() -> T>,
    appearance: Texture<'a>
}
impl<'a, T> Button<'a, T> {
    fn new(hitbox: Rect, callback: Option<fn() -> T>, appearance: Texture<'a>) -> Self {
        Button {
            hitbox, callback, appearance
        }
    }
    fn check(&self, mouse: &MouseState) -> bool {
        self.hitbox.contains_point(Point::new(mouse.x(), mouse.y()))
    }
    fn exec(&self, mouse: &MouseState) -> Option<fn() -> T> {
        if self.check(mouse) && mouse.left() {
            return self.callback
        }
        None
    }
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String> {
        canvas.copy(&self.appearance, None, self.hitbox)?;
        Ok(())
    }
    fn center(&mut self) {
        self.hitbox.x = (SCREEN_WIDTH as i32 - self.hitbox.w as i32) / 2;
        self.hitbox.y = (SCREEN_HEIGHT as i32 - self.hitbox.h as i32) / 2;
    }
}
struct Audio {
    data: kira::sound::static_sound::StaticSoundData,
    current: kira::sound::static_sound::StaticSoundHandle
}
impl Audio {
    fn play(&mut self, manager: &mut kira::manager::AudioManager) {
        if self.current.state() != PlaybackState::Playing {
            self.current = manager.play(self.data.clone()).unwrap();
        }
    }
    fn stop(&mut self, time: u64) {
        if self.current.state() == PlaybackState::Playing {
            self.current.stop(Tween {
                duration: Duration::from_secs(time),
                ..Default::default()
            }).unwrap();
        }    
    }
}
struct Text<'a> {
    content: &'a str,
    size: u16,
    color: Color,
    current: Texture<'a>,
    dst: Rect
}
impl<'a> Text<'a> {
    fn from(content: &'a str, path: &str, size: u16, color: Color, point: Point, ttf: &'a ttf::Sdl2TtfContext, loader: &'a TextureCreator<WindowContext>) -> Self {
        let font = ttf.load_font(path, size).map_err(|e| e.to_string()).unwrap();

        let surface = font
            .render(content)
            .blended(color)
            .map_err(|e| e.to_string())
            .unwrap();

        let text = loader
            .create_texture_from_surface(&surface)
            .map_err(|e| e.to_string())
            .unwrap();
        let (width, height) = text.get_size();
        let dst = Rect::new(point.x(), point.y(), width, height);
        Text {content: &content, size, color, current: text, dst}
    }
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String> {
        canvas.copy(&self.current, None, self.dst)?;
        Ok(())
    }
    fn center(&mut self) {
        self.dst.x = (SCREEN_WIDTH as i32 - self.dst.w as i32) / 2;
        self.dst.y = (SCREEN_HEIGHT as i32 - self.dst.h as i32) / 2;
    }
    fn to_entity(some: Text) -> Entity {
        let anim = Animation::from_texture(some.current, 1, 1, vec![(0, 0)]);
        Entity::from(anim, some.dst.x(), some.dst.y())
    }
}
struct Animal<'a> {
    can_move: bool,
    dir: Direction,
    speed: i32,
    entity: Entity<'a>,
    pen: Hitbox, //map reference
    hittingbox: Option<Hitbox>, //center self reference
}
impl<'a> Animal<'a> {
    fn from(speed: i32, entity: Entity<'a>, pen: Hitbox) -> Self {
        return Animal {can_move: false, dir: Direction::Down, speed, entity, pen, hittingbox: None};
    }
    fn add_hittingbox(&mut self, hittingbox: Hitbox) {
        self.hittingbox = Some(hittingbox);
    }

    fn decide(&mut self) {
        if chance(95) {return}
        let new_dir: u8 = random(0, 4) as u8;
        self.dir = match new_dir {
            0 => Direction::Right,
            1 => Direction::Left,
            2 => Direction::Up,
            3 => Direction::Down,
            _ => panic!()
        }
    }
    fn move_dir(&mut self) {
        if chance(50) {return}
        match self.dir {
            Direction::Down => {self.entity.coords.y += self.speed},
            Direction::Up => {self.entity.coords.y += -self.speed},
            Direction::Right => {self.entity.coords.x += self.speed},
            Direction::Left => {self.entity.coords.x += -self.speed},
        }
        //self.entity.dst()
    }
    fn can_move_self(&self, char: &Character) -> bool {
        let mut hitbox = self.entity.hitbox();

        match self.dir {
            Direction::Down => {
                //hitbox.y += char.speed;
                hitbox.h += self.speed + char.speed;
            }
            Direction::Up => {
                hitbox.y -= self.speed + char.speed;
                hitbox.h += self.speed + char.speed;
            }
            Direction::Right => {
                hitbox.w += self.speed + char.speed;
            }
            Direction::Left => {
                hitbox.x -= self.speed + char.speed;
                hitbox.w += self.speed + char.speed;
            }
        }
        if !self.pen.real.contains_rect(hitbox) {
            return false;
        }
        if hitbox.has_intersection(char.rep.hitbox()) {
            return false;
        }
        true
    }
}
impl Presentable for Animal<'_> {
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String> {
        self.entity.present(canvas)
    }
    fn get_coords(&self) -> Point {
        self.entity.get_coords()
    }
    fn check_move(&mut self, hitbox: Rect) -> bool {
        let result = self.entity.check_move(hitbox);
        self.can_move = result;
        result
    }
    fn set_reference(&mut self, reference: Point) {
        self.entity.set_reference(reference);
        self.pen.update_ref(reference);
    }
    fn get_hitbox(&self) -> Rect {
        self.entity.get_hitbox()
    }
    fn get_z_index(&self) -> u8 {
        self.entity.z_index
    }
    fn behave(&mut self, char: &Character) {
        self.decide();
        if self.can_move_self(char) {
            self.move_dir();
        }
    }
    fn gen_hitbox(&mut self) {
        self.entity.gen_hitbox();
        if self.hittingbox.is_some() {
            self.hittingbox.as_mut().unwrap().update_ref(self.entity.realbox.center());
        }
    }
    fn is_of_type(&self) -> EntityTypes {
        return EntityTypes::Animal
    }
    fn check_hittingbox(&self, other: Rect) -> bool {
        if self.hittingbox.is_some() {
            if self.hittingbox.as_ref().unwrap().real.has_intersection(other) {
                println!("AAAA");
                true
            } else {
                false
            }
        } else {
            false
        }
    }
}
struct Attack {
    on: bool,
    since_last_attack: Instant,
    cooldown_duration: Duration,
    duration: Duration,
}
impl Attack {
    fn new(cooldown_duration: Duration, duration: Duration) -> Self {
        if cooldown_duration < duration {
            panic!("the cooldown of the attack cannot be shorter than the attack itself")
        }
        Attack {
            on: false,
            since_last_attack: Instant::now(),
            cooldown_duration,
            duration
        }
    }
    fn attack(&mut self) {
        if self.since_last_attack.elapsed() >= self.cooldown_duration {
            self.on = true;
            self.since_last_attack = Instant::now(); 
        }
    }
    fn update(&mut self) {
        if self.on {
            if self.since_last_attack.elapsed() >= self.duration {
                self.on = false;
            }
        }
    }
}
struct Enemy<'a> {
    can_move: bool,
    dir: Direction,
    speed: i32,
    entity: Entity<'a>,
    hittingbox: Hitbox,
    attack: Attack,
}
impl<'a> Enemy<'a> {
    fn from(speed: i32, entity: Entity<'a>, hittingbox: Hitbox) -> Self {
        return Enemy {
            can_move: false, 
            dir: Direction::Down, 
            speed, entity, hittingbox,
            attack: Attack::new(Duration::from_secs(2), Duration::from_secs(1))
        };
    }
    fn do_attack_behaviour(&mut self) {
        self.attack.update();
        if chance(98) {return}
        self.attack.attack();
    }
    fn decide(&mut self) {
        if chance(99) {return}
        let new_dir: u8 = random(0, 4) as u8;
        self.dir = match new_dir {
            0 => Direction::Right,
            1 => Direction::Left,
            2 => Direction::Up,
            3 => Direction::Down,
            _ => panic!()
        }
    }
    fn move_dir(&mut self) {
        if chance(50) {return}
        let play = match self.dir {
            Direction::Down => {self.entity.coords.y += self.speed; 1},
            Direction::Up => {self.entity.coords.y += -self.speed; 2},
            Direction::Right => {self.entity.coords.x += self.speed; 3},
            Direction::Left => {self.entity.coords.x += -self.speed; 4},
        };
        self.entity.play(Some(play));
        //self.entity.dst();
    }
    fn can_move_self(&mut self, char: &Character) -> bool {
        let mut hitbox = self.entity.hitbox();


        match self.dir {
            Direction::Down => {
                //hitbox.y += char.speed;
                hitbox.h += self.speed + char.speed;
            }
            Direction::Up => {
                hitbox.y -= self.speed + char.speed;
                hitbox.h += self.speed + char.speed;
            }
            Direction::Right => {
                hitbox.w += self.speed + char.speed;
            }
            Direction::Left => {
                hitbox.x -= self.speed + char.speed;
                hitbox.w += self.speed + char.speed;
            }
        }
        if hitbox.has_intersection(char.rep.hitbox()) {
            return false;
        }
        true
    }
}
impl Presentable for Enemy<'_> {
    fn get_coords(&self) -> Point {
        self.entity.get_coords()
    }
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String> {
        self.entity.present(canvas)
    }
    fn check_move(&mut self, hitbox: Rect) -> bool {
        let result = self.entity.check_move(hitbox);
        self.can_move = result;
        result
    }
    fn get_hitbox(&self) -> Rect {
        self.entity.get_hitbox()    
    }
    fn set_reference(&mut self, reference: Point) {
        self.entity.set_reference(reference);
    }
    fn get_z_index(&self) -> u8 {
        self.entity.z_index
    }
    fn behave(&mut self, char: &Character) {
        self.decide();
        self.do_attack_behaviour();
        self.entity.next();
        if self.can_move_self(char) {
            self.move_dir();
        }
    }
    fn gen_hitbox(&mut self) {
        self.entity.gen_hitbox();
        self.hittingbox.update_ref(self.entity.realbox.center());
    }
    fn is_of_type(&self) -> EntityTypes {
        return EntityTypes::Enemy
    }
    fn check_hittingbox(&self, other: Rect) -> bool {
        if self.hittingbox.real.has_intersection(other) && self.attack.on {
            println!("AAAA");
            true
        } else {
            false
        }
    }
}
struct World<'a> {
    x: i32,
    y: i32,
    map: ComplexHitbox<'a>,
    entities: Vec<Box<dyn Presentable + 'a>>,
    interactables: Vec<Interactable>,
    e: Entity<'a>,
    char: Character<'a>,
}


impl<'a> World<'a> {
    fn from(map: ComplexHitbox<'a>, entities: Vec<Entity<'a>>, highest: u8, char: Character<'a>, loader: &'a TextureCreator<WindowContext>) -> Self {
        let mut entities_n: Vec<Box<dyn Presentable>> = vec![];
        for entity in entities {
            entities_n.push(Box::new(entity))
        }
        World {
            x: 0,
            y: 0,
            map,
            entities: entities_n,
            interactables: vec![],
            e: Entity::new(
                vec![Animation::new("assets/E.png", 1, 1, vec![(0, 0)], loader)],
                0, 0, 0,
                Point::new(0, 0),
            ),
            char
        }
    }
    fn check_hits(&mut self){
        for entity in &self.entities {
            if entity.check_hittingbox(self.char.rep.realbox) {
                self.char.damage();
            }
        }
    }
    fn add_interaction(&mut self, interactable: Interactable) {
        self.interactables.push(interactable);
    }
    fn add<T: Presentable + 'a>(&mut self, entity: T) {
        self.entities.push(Box::new(entity));
    }
    fn can_move(&mut self, dir: Direction) -> bool {
        let mut hitbox = self.char.rep.realbox;

        match dir {
            Direction::Down => {
                //hitbox.y += char.speed;
                hitbox.h += self.char.speed;
            }
            Direction::Up => {
                hitbox.y -= self.char.speed;
                hitbox.h += self.char.speed;
            }
            Direction::Right => {
                hitbox.w += self.char.speed;
            }
            Direction::Left => {
                hitbox.x -= self.char.speed;
                hitbox.w += self.char.speed;
            }
        }
        if self.map.collide_all(hitbox) {
            return false
        }

        for entity in &mut self.entities {
            if !entity.check_move(hitbox) {
                return false
            }
        }

        true
    }
    fn do_behaviours(&mut self) {
            for entity in &mut self.entities {
                entity.behave(&self.char);
            }
    }
    fn reorder_char(&mut self) {
        self.entities.sort_by(|a, b| a.get_hitbox().y().cmp(&b.get_hitbox().y()));

        let vec: Vec<Rect> = self.entities.iter().map(|x| x.get_hitbox()).collect();
        //println!("{:?} {:?}", vec, self.char.rep.get_hitbox());
    }
    fn check_interact(&mut self, keyboard: &KeyboardState, canvas: &mut WindowCanvas) -> Option<(fn() -> bool, u8)> {
        let mut i = 0;
        for act in &mut self.interactables {
            act.update_ref(self.map.base.dst.top_left());
            if act.check(self.char.rep.realbox) {
                self.e.set_reference(act.hitbox().center());
                self.e.present(canvas).unwrap(); 

                //self.present_interact(canvas, act.hitbox).unwrap();
                if let Some(x) = act.exec(keyboard) {
                    return Some((x, i))
                }
            }
        }
        None
    }
    fn present(&mut self, canvas: &mut WindowCanvas) -> Result<(), String> {
        self.char.rep.next();

        self.map.base.present(canvas)?;

        let mut taken = false;
        for entity in &mut self.entities {
            entity.set_reference(self.map.base.dst.top_left());
            entity.gen_hitbox();
            if !taken {
                if self.char.rep.get_hitbox().y() <= entity.get_hitbox().y()  {
                    self.char.rep.present(canvas)?;
                    taken = true;
                }
            }
            entity.present(canvas)?;
                //canvas.fill_rect(hitbox)?;
        }
        if !taken {
            self.char.rep.present(canvas)?;
        }
        self.char.present(canvas)?;

        Ok(())
    }
    fn present_interact(&self, canvas: &mut WindowCanvas, other: Rect) -> Result<(), String> {
            //self.x + other.x() + (other.width() / 2) as i32, 
            //self.y + other.y() + (other.height() / 2) as i32)?;
        Ok(())
    }
    fn movement(&mut self, keyboard: &KeyboardState) -> bool {
        let mut moved = false;
        if keyboard.is_scancode_pressed(Scancode::D) {
            if self.can_move(Direction::Right) {
                let dir = Direction::Right;
                self.map.base.coords.x -= self.char.speed;
                self.char.dir = dir;
                self.char.rep.switch_to(dir as usize);
                moved = true;
            }
        }
        else if keyboard.is_scancode_pressed(Scancode::A) {
            if self.can_move(Direction::Left) {
                let dir = Direction::Left;
                self.map.base.coords.x += self.char.speed;
                self.char.dir = dir;
                self.char.rep.switch_to(dir as usize);
                moved = true;
            }
        }
        if keyboard.is_scancode_pressed(Scancode::W) {
            if self.can_move(Direction::Up) {
                let dir = Direction::Up;
                self.map.base.coords.y += self.char.speed;
                self.char.dir = dir;
                self.char.rep.switch_to(dir as usize);
                moved = true;
            }
        }
        else if keyboard.is_scancode_pressed(Scancode::S) {
            if self.can_move(Direction::Down) {
                let dir = Direction::Down;
                self.map.base.coords.y -= self.char.speed;
                self.char.dir = dir;
                self.char.rep.switch_to(dir as usize);
                moved = true;
            }
        }
        moved
    }
}

#[derive(PartialEq, Copy, Clone)]
enum Direction {
    Left = 1,
    Right = 2,
    Up = 3,
    Down = 4,
}
struct Character<'a> {
    rep: Entity<'a>, //the character's representation: an entity
    dir: Direction, //the direction the character is facing
    speed: i32,
    dodge_cooldown: Instant,
    health: u8,
    damage_cooldown: Instant,
    hearts: Vec<Entity<'a>>,
}
const DODGE_COOLDOWN: u64 = 2;
const DAMAGE_COOLDOWN: u64 = 2;
impl<'a> Character<'a> {
    fn new(rep: Entity<'a>, hearts: Vec<Entity<'a>>) -> Self {
        Character { 
            rep, 
            dir: Direction::Right, 
            speed: 3, 
            dodge_cooldown: Instant::now(), 
            health: 3*4,
            damage_cooldown: Instant::now(),
            hearts
        }
    }
    fn damage(&mut self) {
        if self.damage_cooldown.elapsed() > Duration::from_secs(DAMAGE_COOLDOWN) {
            self.health -= 1;
            match self.health {
                8..=12 => {
                    self.hearts[0].play(None);
                    self.hearts[0].next();
                    self.hearts[0].stop();
                },
                4..=7 => {
                    self.hearts[1].play(None);
                    self.hearts[1].next();
                    self.hearts[1].stop();
                }
                1..=3 => {
                    self.hearts[2].play(None);
                    self.hearts[2].next();
                    self.hearts[2].stop();
                }
                0 => {
                    self.hearts[2].play(None);
                    self.hearts[2].next();
                    self.hearts[2].stop();
                    self.rep.play(Some(5));
                }
                _ => {}
            }
            self.damage_cooldown = Instant::now();
        }

    }
    fn speed(&mut self, keyboard: &KeyboardState, dash: &mut Entity<'a>) -> bool {
        if keyboard.is_scancode_pressed(Scancode::LShift) {
            self.speed = 5;
        } else {
            self.speed = 3
        }
        if self.dodge_cooldown.elapsed() < Duration::from_millis(150) {
            self.speed = 18;
        }
        //checking for dash
        if keyboard.is_scancode_pressed(Scancode::LAlt) {
            if self.dodge_cooldown.elapsed() > Duration::from_secs(DODGE_COOLDOWN) {
                let anim = self.dir as usize + 5;
                self.rep.play(Some(anim));
                self.speed = 20;
                dash.play(None);
                self.dodge_cooldown = Instant::now();
                return true
            }
        }
        false
    }
    fn present(&mut self, canvas: &mut WindowCanvas) -> Result<(), String> {
        for heart in &self.hearts {
            heart.present(canvas)?;
        } 

        Ok(())
    }
}
struct Entity<'a> {
    coords: Point,
    active: usize, //the number of the active animation from the animations list
    last: usize, //the number of the previous active animation
    animations: Vec<Animation<'a>>, //a list containing the entity's animations
    dst: Rect, //the destination where SDL2 will put the entity on the screen
    z_index: u8, //the layer number
    hitbox: Rect,
    realbox: Rect,
    reference: Point,
} 
impl<'a> Entity<'a> {
    fn current_as_ref(&self) -> &Animation {
        &self.animations[self.active]
    }
    fn from(base: Animation<'a>, x: i32, y: i32) -> Self {
        let (unit_w, unit_h) = base.get_units();
        let dst = Rect::new(x, y, unit_w, unit_h);
        Entity {
            coords: Point::new(x, y),
            active: 0,
            last: 0,
            animations: vec![base],
            dst,
            z_index: 0,
            hitbox: dst,
            realbox: dst,
            reference: Point::new(0, 0)
        }
    }
    fn movable(&self) -> bool {
        self.animations[self.active].movable
    }
    fn new(animations: Vec<Animation<'a>>, x:i32, y:i32, z: u8, reference: Point) -> Self {
        let (unit_w, unit_h) = animations[0].get_units();
        let dst = Rect::new(x, y, unit_w, unit_h);
        Entity {
            coords: Point::new(x, y),
            active: 0,
            last: 0,
            animations,
            dst,
            z_index: z,
            hitbox: dst,
            realbox: dst,
            reference
        }
    }
    fn offset_x(&mut self, value: i32) {
        self.dst.x += value;
        self.hitbox.x += value;
        self.dst();
    }
    fn offset_y(&mut self, value: i32) {
        self.dst.y += value;
        self.hitbox.y += value;
        self.dst();
    }
    fn mult_w(&mut self, value: f32) {
        self.dst.w = (self.dst.w as f32 * value) as i32;
        self.hitbox.w = (self.hitbox.w as f32 * value) as i32;
        self.dst()
    }
    fn mult_h(&mut self, value: f32) {
        self.dst.h = (self.dst.h as f32 * value) as i32;
        self.hitbox.h = (self.hitbox.h as f32 * value) as i32;
        self.dst()
    }
    fn mult(&mut self, value: f32) {
        self.mult_w(value);
        self.mult_h(value);
    }
    fn mult_until_w(&mut self, value: f32) -> f32 {
        let size_change = value / self.dst.w as f32;
        self.mult(size_change);
        size_change
    }
    fn mult_until_h(&mut self, value: f32) -> f32 {
        let size_change = value / self.dst.h as f32;
        self.mult(size_change);
        size_change
    }
    fn center(&mut self) {
        self.dst.x = (SCREEN_WIDTH as i32 - self.dst.w) / 2;
        self.dst.y = (SCREEN_HEIGHT as i32 - self.dst.h) / 2;
        self.dst.x = self.dst.x;
        self.dst.y = self.dst.y;
    }
    fn dst(&mut self) {
        let x = self.reference.x() + self.coords.x - (self.dst.w as i32 / 2);
        let y = self.reference.y() + self.coords.y - (self.dst.h as i32 / 2);
        self.dst.x = x;
        self.dst.y = y;
    }
    fn switch_to(&mut self, num: usize) {
        if self.active != num && self.animations[self.active].interruptable {
            self.last = self.active;
            self.active = num;
        }
    }
    fn play(&mut self, num: Option<usize>) {
        match num {
            Some(x) => {
                self.switch_to(x)
            }
            None => {()}
        }
        self.animations[self.active].ongoing = true;
    }
    fn stop(&mut self) {
        self.animations[self.active].ongoing = false;
    }
    fn force_switch(&mut self, num: usize) {
        self.active = num;
    }
    fn next(&mut self) {
        if self.animations[self.active].next() {
            self.force_switch(self.last);
        }
    }
    fn clone(&self, loader: &'a TextureCreator<WindowContext>) -> Self {
        let mut animations = Vec::new();
        for elem in &self.animations {
            animations.push(elem.clone(loader))
        }
        Entity {coords: self.coords, active: self.active, last: self.last, animations, dst: self.dst, z_index: self.z_index, hitbox: self.hitbox, reference: self.reference, realbox: self.realbox }
    }
    fn hitbox(&self) -> Rect {
        let mut entity_hitbox = self.hitbox;
        entity_hitbox.x += self.dst.x();
        entity_hitbox.y += self.dst.y();
        entity_hitbox
    }
}
impl Presentable for Entity<'_> {
    fn gen_hitbox(&mut self) {
        self.realbox = self.hitbox();
    }
    fn get_coords(&self) -> Point {
        self.coords
    }
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String> {
        //destination.x += self.reference.x();
        //destination.y += self.reference.y();
        canvas.copy(
            &self.animations[self.active].sheet, 
            self.animations[self.active].get_src(),
            self.dst)?;
        //canvas.fill_rect(self.hitbox)?;
        Ok(())
    }
    fn check_move(&mut self, hitbox: Rect) -> bool {
        let entity_hitbox = self.realbox;
        if hitbox.has_intersection(entity_hitbox) {
            return false
        }
        true
    }
    fn set_reference(&mut self, reference: Point) {
        self.reference = reference;
        self.dst();
    }
    fn get_hitbox(&self) -> Rect {
        self.hitbox()
    }
    fn get_z_index(&self) -> u8 {
        self.z_index
    }
    fn behave(&mut self, _char: &Character) {
        return
    }
    fn is_of_type(&self) -> EntityTypes {
        return EntityTypes::Plain
    }
    fn check_hittingbox(&self, other: Rect) -> bool {
        false
    }
}
struct Animation<'a> {
    sheet: Texture<'a>, //the sheet from which the frames of the animation are sourced
    source: String, //the path to the image file containing the sheet
    rows: u8, //the number of rows (frames) on the sheet
    cols: u8, //the no. of cols (frames) on the sheet
    current_frame: (u8, u8, Option<Rect>), //the coordinate for the frame on the sheet, (x, y) = (col, row)
    current: usize, //number of the current frame out of the total no. of frames
    frames: Vec<(u8, u8, Option<Rect>)>, //a sequence containing the frames' coordinates
    total: usize, //the length of the sequence
    ongoing: bool, //is the animation ongoing
    dur: Duration, //the amount of time that needs to elapse between frames
    elapse: Instant, //stopper-watch used to measure the elapse of time
    interruptable: bool, //can the animation be interrupted by another animation
    looped: bool, //is the animation on a loop
    movable: bool, //can the entity move while displaying this animation
} 
impl<'a> Animation<'a> {
    fn get_units(&self) -> (u32, u32) {
        let (w, h) = self.sheet.get_size();
        let unit_w = w / self.cols as u32;
        let unit_h = h / self.rows as u32;
        (unit_w, unit_h)
    }
    fn get_src(&self) -> Rect {
        if let Some(src) = self.current_frame.2 {
            //println!("{:?}", src);
            return src
        } else {
            //println!("{:?}", self.current_frame.2);
            let (unit_w, unit_h) = self.get_units();
            let (i, j, _) = self.current_frame;
            Rect::new(i as i32 * unit_w as i32, j as i32 * unit_h as i32, unit_w, unit_h)
        }
    }
    fn new(filename: &str, rows: u8, cols: u8, frames: Vec<(u8, u8)>, loader: &'a TextureCreator<WindowContext>) -> Self {
        let total = frames.len() - 1;
        let mut frames_new = vec![];
        for frame in frames {
            let frame_new = (frame.0, frame.1, None);
            frames_new.push(frame_new);
        }
        Animation {
            sheet: loader.load_texture(filename).unwrap(), 
            source: filename.to_string(),
            rows, 
            cols, 
            current_frame: frames_new[0], 
            current: 0, 
            frames: frames_new, 
            total, 
            ongoing: true, 
            dur: Duration::from_millis(DEFAULT_ANIMATION_LENGTH), 
            elapse: Instant::now(),
            interruptable: true,
            looped: true,
            movable: true,
        }
    }
    fn from(filename: &str, rows: u8, cols: u8, frames: Vec<(u8, u8)>, ongoing: bool, looped: bool, movable: bool, interruptable: bool, dur: Duration, loader: &'a TextureCreator<WindowContext>) -> Self {
        let total = frames.len() - 1;
        let mut frames_new = vec![];
        for frame in frames {
            let frame_new = (frame.0, frame.1, None);
            frames_new.push(frame_new);
        }
        Animation {
            sheet: loader.load_texture(filename).unwrap(), 
            source: filename.to_string(),
            rows, 
            cols, 
            current_frame: frames_new[0], 
            current: 0, 
            frames: frames_new, 
            total, 
            ongoing,
            dur, 
            elapse: Instant::now(),
            interruptable,
            looped,
            movable
        }
    }
    fn from_texture(texture: Texture<'a>, rows: u8, cols: u8, frames: Vec<(u8, u8)>) -> Self {
        let total = frames.len() - 1;
        let mut frames_new = vec![];
        for frame in frames {
            let frame_new = (frame.0, frame.1, None);
            frames_new.push(frame_new);
        }
        Animation {
            sheet: texture, 
            source: "".to_string(),
            rows, 
            cols, 
            current_frame: frames_new[0], 
            current: 0, 
            frames: frames_new, 
            total, 
            ongoing: true, 
            dur: Duration::from_millis(100), 
            elapse: Instant::now(),
            interruptable: true,
            looped: true,
            movable: true,
        }
    }
    fn has_ended(&self) -> bool {
        self.current == self.total
    }
    fn next(&mut self) -> bool {
        if self.elapse.elapsed() < self.dur {
            return false
        }
        if !self.ongoing {
            return true
        }
        if self.current == self.total {
            self.current = 0;
            if !self.looped {
                self.current_frame = self.frames[self.current];
                self.ongoing = false;
                return true
            }
        } else {
            self.current += 1;
        }

        self.current_frame = self.frames[self.current];
        self.elapse = Instant::now();
        return false       
    }
    fn clone(&self, loader: &'a TextureCreator<WindowContext>) -> Self {
        Animation {
            sheet: loader.load_texture(self.source.clone()).unwrap(),
            source: self.source.clone(), 
            rows: self.rows, 
            cols: self.cols, 
            current_frame: self.current_frame, 
            current: self.current, 
            frames: self.frames.clone(), 
            total: self.total, 
            ongoing: self.ongoing, 
            dur: self.dur, 
            elapse: self.elapse, 
            interruptable: self.interruptable, 
            looped: self.looped,
            movable: self.movable
        }
    }
}

trait Sized {
    fn get_size(&self) -> (u32, u32);
} impl Sized for Texture<'_> {
    fn get_size(&self) -> (u32, u32) {
        let query = self.query();
        let width = query.width;
        let height = query.height;
        (width, height)
    }
}

trait Presentable {
    fn get_coords(&self) -> Point;
    fn get_hitbox(&self) -> Rect;
    fn get_z_index(&self) -> u8;
    fn present(&self, canvas: &mut WindowCanvas) -> Result<(), String>;
    fn check_move(&mut self, hitbox: Rect) -> bool;
    fn behave(&mut self, char: &Character);
    fn set_reference(&mut self, reference: Point);
    fn gen_hitbox(&mut self);
    fn is_of_type(&self) -> EntityTypes;
    fn check_hittingbox(&self, other: Rect) -> bool;
}
#[derive(Debug, PartialEq, Eq, PartialOrd, Ord)]
enum EntityTypes {
    Plain,
    Animal,
    Enemy
}

fn random(start: i32, end: i32) -> i32 {
    let mut rng = thread_rng();
    rng.gen_range(start..end)
}
fn chance(percent: u8) -> bool {
    random(1, 101) < percent as i32
}
fn size_up<T: AsPrimitive<f32>>(num: T, mult: f32) -> i32 {
    (num.as_() * mult) as i32
}

struct Hitbox {
    ideal: Rect,
    real: Rect,
    reference: Point,
}
impl Hitbox {
    fn gen_real(mut ideal: Rect, reference: Point) -> Rect {
        ideal.x += reference.x;
        ideal.y += reference.y;
        ideal
    }
    fn gen_real_owned(&mut self) {
        self.real = Hitbox::gen_real(self.ideal, self.reference);
    }
    fn new(ideal: Rect, reference: Point) -> Self {
        Hitbox {
            ideal,
            real: Hitbox::gen_real(ideal, reference),
            reference,
        }
    }
    fn update_ref(&mut self, reference: Point) {
        self.reference = reference;
        self.gen_real_owned();
    }
}

struct Percent;
impl Percent {
    fn f32<T: AsPrimitive<f32>>(num: T, percent: f32) -> f32 {
        num.as_() * (percent / 100.0)
    }
    fn i32<T: AsPrimitive<f32>>(num: T, percent: f32) -> i32 {
        (num.as_() * (percent / 100.0f32)) as i32
    }
}

